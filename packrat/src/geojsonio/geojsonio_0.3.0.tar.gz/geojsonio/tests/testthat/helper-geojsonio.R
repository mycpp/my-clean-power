gdel <- function(x) {
  invisible(gistr::delete(x))  
}

supw <- function(x) suppressWarnings(x)
